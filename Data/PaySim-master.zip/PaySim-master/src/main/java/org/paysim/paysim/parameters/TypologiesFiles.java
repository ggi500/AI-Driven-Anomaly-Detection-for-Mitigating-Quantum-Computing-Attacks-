package org.paysim.paysim.parameters;

public class TypologiesFiles {
    public static final String drugNetworkOne = "DrugNetworkOne.graphml";
}
